# ceres_icp

## ceres
pleas install ceres firs. You can follow this website http://www.ceres-solver.org/

## install boost

`` sudo apt-get install libboost-all-dev ``


## install eigen
`` sudo apt-get install libeigen3-dev ``

## install glew
`` sudo apt-get install libglew-dev ``

## g2o
please install g2o. You can follow this one https://github.com/RainerKuemmerle/g2o
